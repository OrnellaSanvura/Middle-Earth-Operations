﻿using System;

namespace PracticeTest
{
    public class Gandalf : Character
    {
        public string StaffType { get; set; }

        public Gandalf(
            int id,
            string name,
            int age,
            int strengthLevel,
            string staffType)
            : base(id, name, age, strengthLevel)
        {
            StaffType = staffType;
        }

        public override void PerformAction()
        {
            Console.WriteLine(
                Name + " is investigating an ancient ruin with his " + StaffType + "."
            );
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine("Staff Type: " + StaffType);
        }
    }
}