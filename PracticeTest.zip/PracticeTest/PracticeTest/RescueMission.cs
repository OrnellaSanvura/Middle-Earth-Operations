﻿using System;

namespace PracticeTest
{
    public class RescueMission : Mission, IMission
    {
        public RescueMission(
            int missionId,
            string name,
            string location,
            int dangerLevel)
            : base(missionId, name, location, dangerLevel)
        {
        }

        public void ExecuteMission()
        {
            Console.WriteLine(
                "Rescuing a captured character at " + Location + "..."
            );

            System.Threading.Thread.Sleep(2000);

            IsCompleted = true;

            Console.WriteLine(
                "Rescue mission '" + Name + "' completed."
            );
        }
    }
}