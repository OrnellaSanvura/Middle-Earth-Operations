﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            OperationsManager manager = new OperationsManager();

            bool running = true;

            while (running)
            {
                Console.WriteLine();
                Console.WriteLine("================================");
                Console.WriteLine("     MIDDLE-EARTH OPERATIONS");
                Console.WriteLine("================================");
                Console.WriteLine("1. Add Character");
                Console.WriteLine("2. Display Characters");
                Console.WriteLine("3. Add Mission");
                Console.WriteLine("4. Display Missions");
                Console.WriteLine("5. Add Threat");
                Console.WriteLine("6. Start Operations");
                Console.WriteLine("7. Exit");
                Console.WriteLine();
                Console.Write("Select an option: ");

                string choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            AddCharacters(manager);
                            break;

                        case "2":
                            manager.DisplayCharacters();
                            break;

                        case "3":
                            AddMission(manager);
                            break;

                        case "4":
                            manager.DisplayMissions();
                            break;

                        case "5":
                            AddThreat(manager);
                            break;

                        case "6":
                            manager.StartOperations();
                            break;

                        case "7":
                            running = false;
                            Console.WriteLine("Goodbye!");
                            break;

                        default:
                            Console.WriteLine("Invalid option.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
                finally
                {
                    Console.WriteLine("Returning to menu...");
                }
            }
        }

        static void AddCharacters(OperationsManager manager)
        {
            Console.WriteLine();
            Console.WriteLine("Choose a character:");
            Console.WriteLine("1. Aragorn");
            Console.WriteLine("2. Gandalf");
            Console.WriteLine("3. Legolas");
            Console.WriteLine("4. Gollum");
            Console.Write("Choice: ");

            string choice = Console.ReadLine();

            Character character;

            switch (choice)
            {
                case "1":
                    character = new Aragorn(
                        1,
                        "Aragorn",
                        87,
                        9,
                        "Sword"
                    );
                    break;

                case "2":
                    character = new Gandalf(
                        2,
                        "Gandalf",
                        2000,
                        10,
                        "Wizard Staff"
                    );
                    break;

                case "3":
                    character = new Legolas(
                        3,
                        "Legolas",
                        2931,
                        8,
                        "Long Bow"
                    );
                    break;

                case "4":
                    character = new Gollum(
                        4,
                        "Gollum",
                        589,
                        5,
                        "Misty Mountains Cave"
                    );
                    break;

                default:
                    Console.WriteLine("Invalid character.");
                    return;
            }

            manager.AddCharacter(character);

            Console.WriteLine(
                character.Name + " added successfully."
            );
        }

        static void AddMission(OperationsManager manager)
        {
            Console.WriteLine();
            Console.WriteLine("Choose a mission:");
            Console.WriteLine("1. Search Mission");
            Console.WriteLine("2. Rescue Mission");
            Console.WriteLine("3. Combat Mission");
            Console.Write("Choice: ");

            string choice = Console.ReadLine();

            Mission mission;

            switch (choice)
            {
                case "1":
                    mission = new SearchMission(
                        1,
                        "Find Gollum",
                        "Mirkwood Forest",
                        7
                    );
                    break;

                case "2":
                    mission = new RescueMission(
                        2,
                        "Rescue Soldier",
                        "Moria",
                        8
                    );
                    break;

                case "3":
                    mission = new CombatMission(
                        3,
                        "Fight Orcs",
                        "Mordor",
                        10
                    );
                    break;

                default:
                    Console.WriteLine("Invalid mission.");
                    return;
            }

            manager.AddMission(mission);

            Console.WriteLine(
                mission.Name + " added successfully."
            );
        }

        static void AddThreat(OperationsManager manager)
        {
            Console.Write("Threat ID: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Threat Name: ");
            string name = Console.ReadLine();

            Console.Write("Location: ");
            string location = Console.ReadLine();

            Console.Write("Danger Level (1-10): ");
            int dangerLevel = int.Parse(Console.ReadLine());

            Threat threat = new Threat(
                id,
                name,
                location,
                dangerLevel
            );

            manager.AddThreat(threat);

            Console.WriteLine("Threat added successfully.");
        }
    }
}