﻿using System;

namespace PracticeTest
{
    public class Gollum : Character
    {
        public string CaveLocation { get; set; }

        public Gollum(
            int id,
            string name,
            int age,
            int strengthLevel,
            string caveLocation)
            : base(id, name, age, strengthLevel)
        {
            CaveLocation = caveLocation;
        }

        public override void PerformAction()
        {
            Console.WriteLine(
                Name + " is hiding in " + CaveLocation + "."
            );
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine("Cave Location: " + CaveLocation);
        }
    }
}
