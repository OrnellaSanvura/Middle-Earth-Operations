﻿using System;

namespace PracticeTest
{
    public class Legolas : Character
    {
        public string BowType { get; set; }

        public Legolas(
            int id,
            string name,
            int age,
            int strengthLevel,
            string bowType)
            : base(id, name, age, strengthLevel)
        {
            BowType = bowType;
        }

        public override void PerformAction()
        {
            Console.WriteLine(
                Name + " is scouting the mountains with his " + BowType + "."
            );
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine("Bow Type: " + BowType);
        }
    }
}