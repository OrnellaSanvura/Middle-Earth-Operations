﻿using System;

namespace PracticeTest
{
    public class SearchMission : Mission, IMission
    {
        public SearchMission(
            int missionId,
            string name,
            string location,
            int dangerLevel)
            : base(missionId, name, location, dangerLevel)
        {
        }

        public void ExecuteMission()
        {
            Console.WriteLine(
                "Searching for Gollum at " + Location + "..."
            );

            System.Threading.Thread.Sleep(2000);

            IsCompleted = true;

            Console.WriteLine(
                "Search mission '" + Name + "' completed."
            );
        }
    }
}