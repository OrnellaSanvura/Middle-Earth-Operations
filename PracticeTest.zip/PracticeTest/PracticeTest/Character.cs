﻿using System;

namespace PracticeTest
{
    public abstract class Character
    {
        // Common information for every character
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int StrengthLevel { get; set; }

        // Constructor
        public Character(int id, string name, int age, int strengthLevel)
        {
            Id = id;
            Name = name;
            Age = age;
            StrengthLevel = strengthLevel;
        }

        // Common action
        public virtual void PerformAction()
        {
            Console.WriteLine(Name + " is performing an operation.");
        }

        // Display character information
        public virtual void DisplayInfo()
        {
            Console.WriteLine("ID: " + Id);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Age: " + Age);
            Console.WriteLine("Strength Level: " + StrengthLevel);
        }
    }
}