﻿using System;

namespace PracticeTest
{
    public abstract class Mission
    {
        public int MissionId { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int DangerLevel { get; set; }
        public bool IsCompleted { get; set; }

        public Mission(
            int missionId,
            string name,
            string location,
            int dangerLevel)
        {
            MissionId = missionId;
            Name = name;
            Location = location;
            DangerLevel = dangerLevel;
            IsCompleted = false;
        }

        public virtual void DisplayInfo()
        {
            Console.WriteLine("Mission ID: " + MissionId);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Location: " + Location);
            Console.WriteLine("Danger Level: " + DangerLevel);
            Console.WriteLine("Completed: " + IsCompleted);
        }
    }
}