﻿namespace PracticeTest
{
    public interface IMission
    {
        void ExecuteMission();
    }
}
