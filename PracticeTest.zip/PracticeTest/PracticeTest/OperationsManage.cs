﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace PracticeTest
{
    public class OperationsManager
    {
        private List<Character> characters = new List<Character>();
        private List<Mission> missions = new List<Mission>();
        private List<Threat> threats = new List<Threat>();

        public void AddCharacter(Character character)
        {
            characters.Add(character);
        }

        public void DisplayCharacters()
        {
            Console.WriteLine("\n--- CHARACTERS ---");

            foreach (Character character in characters)
            {
                character.DisplayInfo();
                Console.WriteLine();
            }
        }

        public void AddMission(Mission mission)
        {
            missions.Add(mission);
        }

        public void DisplayMissions()
        {
            Console.WriteLine("\n--- MISSIONS ---");

            foreach (Mission mission in missions)
            {
                mission.DisplayInfo();
                Console.WriteLine();
            }
        }

        public void AddThreat(Threat threat)
        {
            threats.Add(threat);
        }

        public void DisplayThreats()
        {
            Console.WriteLine("\n--- THREATS ---");

            foreach (Threat threat in threats)
            {
                threat.DisplayInfo();
            }
        }

        public void StartOperations()
        {
            Console.WriteLine("\n--- OPERATIONS STARTING ---");

            List<Thread> threads = new List<Thread>();

            foreach (Character character in characters)
            {
                Character currentCharacter = character;

                Thread thread = new Thread(() =>
                {
                    Console.WriteLine(
                        currentCharacter.Name + " operation STARTED."
                    );

                    Thread.Sleep(3000);

                    currentCharacter.PerformAction();

                    Console.WriteLine(
                        currentCharacter.Name + " operation FINISHED."
                    );
                });

                threads.Add(thread);
                thread.Start();
            }

            foreach (Thread thread in threads)
            {
                thread.Join();
            }

            Console.WriteLine("All operations completed.");
        }
    }
}