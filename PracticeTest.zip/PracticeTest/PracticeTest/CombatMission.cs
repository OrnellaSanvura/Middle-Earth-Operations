﻿using System;

namespace PracticeTest
{
    public class CombatMission : Mission, IMission
    {
        public CombatMission(
            int missionId,
            string name,
            string location,
            int dangerLevel)
            : base(missionId, name, location, dangerLevel)
        {
        }

        public void ExecuteMission()
        {
            Console.WriteLine(
                "Fighting enemy forces at " + Location + "..."
            );

            System.Threading.Thread.Sleep(2000);

            IsCompleted = true;

            Console.WriteLine(
                "Combat mission '" + Name + "' completed."
            );
        }
    }
}