﻿using System;

namespace PracticeTest
{
    public class InvalidThreatException : Exception
    {
        public InvalidThreatException(string message)
            : base(message)
        {
        }
    }
}