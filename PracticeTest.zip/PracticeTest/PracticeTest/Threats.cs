﻿using System;

namespace PracticeTest
{
    public class Threat
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int DangerLevel { get; set; }

        public Threat(
            int id,
            string name,
            string location,
            int dangerLevel)
        {
            if (dangerLevel < 1 || dangerLevel > 10)
            {
                throw new InvalidThreatException(
                    "Danger level must be between 1 and 10."
                );
            }

            Id = id;
            Name = name;
            Location = location;
            DangerLevel = dangerLevel;
        }

        public void DisplayInfo()
        {
            Console.WriteLine(
                "Threat: " + Name +
                " | Location: " + Location +
                " | Danger: " + DangerLevel
            );
        }
    }
}